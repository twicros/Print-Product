
Elastislide
=========

Elastislide is a responsive image carousel that will adapt fluidly in a layout. It is a jQuery plugin that can be laid out horizontally or vertically with a pre-defined minimum number of shown images

[article on Codrops](http://tympanus.net/codrops/2011/09/12/elastislide-responsive-carousel/)

[demo](http://tympanus.net/Development/Elastislide/)

Licensed under the MIT License