$(function () {
	$('.carousel').carousel({
		interval: false
	});



	$("a[href^='#']").on('click', function(e) {

	   // prevent default anchor click behavior
	   e.preventDefault();

	   // store hash
	   var hash = this.hash;

	   // animate
	   $('html, body').animate({
	       scrollTop: $(hash).offset().top-100
	     }, 1000, function(){

	       // when done, add hash to url
	       // (default click behaviour)
	       window.location.hash = hash;
	     });

	});
	
});


$(document).ready(function(){
    $(":input").inputmask();
	$("div.ecwid-search-widget").addClass("ecwid-search-widget--collapsed");
});

