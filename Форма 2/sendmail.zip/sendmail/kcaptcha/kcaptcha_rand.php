<center><a href='kcaptcha/kcaptcha_copy.php' target='_blank'><font size=-2 color=#dddddd>�</font></a></center>
<center><a href='readme.html'> </a></center>